import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-scanner-de-vacina',
  templateUrl: 'scanner-de-vacina.html'
})
export class ScannerDeVacinaPage {

  constructor(public navCtrl: NavController) {
  }
  
}
